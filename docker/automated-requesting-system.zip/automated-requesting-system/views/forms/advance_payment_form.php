<?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['error']) ?></div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>
<form method="POST" action="<?= url('forms/advance-payment') ?>">
    <div class="page-heading">Advance Payment Request</div>
    <div class="page-subheading">Fill in the details below. Save as draft to continue later, or submit directly for approval.</div>
    
    <?= \App\Helpers\Csrf::field(); ?>

    <div class="form-card">
        <div class="form-section-title">Applicant Details</div>
        <div class="form-grid g-4">
            <div class="form-group"><label>Applicant</label><input type="text" name="employee_name" value="<?= htmlspecialchars($currentUser ?? '') ?>" readonly required></div>
            <div class="form-group">
                <label>Department</label>
                <div class="input-select">
                    <input type="text" name="department" list="dept-list" autocomplete="off" required>
                    <datalist id="dept-list">
                        <?php foreach ($departments ?? [] as $dept): ?>
                            <option value="<?= htmlspecialchars($dept) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
            </div>
            <div class="form-group"><label>Pages</label><input type="text" name="page_no" placeholder="No. of attachments"></div>
            <div class="form-group"><label>Date</label><input type="date" name="date" required></div>
        </div>
        <div class="form-group mt-1">
            <label>Project Name</label><input type="text" name="project_name">
        </div>
    </div>

    <div class="form-card">
        <div class="form-section-title">Payment Details</div>
        <div class="form-grid g-4">
            <div class="form-group">
                <label>Type of Payment</label>
                <select name="payment_type" required>
                    <option value="">-- Select --</option>
                    <option>Cash</option>
                    <option>Bank Transfer</option>
                    <option>Cheque</option>
                </select>
            </div>
            <div class="form-group"><label>Payee</label><input type="text" name="payee" required></div>
            <div class="form-group"><label>Account Name</label><input type="text" name="account_name"></div>
            <div class="form-group"><label>Bank Name</label><input type="text" name="bank_name"></div>
            <div class="form-group"><label>Bank Account No.</label><input type="text" name="bank_account_no"></div>
            <div class="form-group"><label>Address</label><input type="text" name="address"></div>
        </div>
        <div class="form-group mt-1">
            <label>Purpose</label><textarea name="purpose" rows="2"></textarea>
        </div>
    </div>

    <div class="form-card">
        <div class="form-section-title">Item Details</div>
        <div class="table-scroll">
            <table class="form-table" id="items-table"
                data-recalc="items"
                data-add-btn-id="add-row"
                data-total-id="total_amount"
            >
                <thead><tr><th>Item</th><th>Description</th><th>Unit Price</th><th>Quantity</th><th>Amount</th><th></th></tr></thead>
                <tbody>
                    <tr>
                        <td><input type="text" name="item[]"></td>
                        <td><input type="text" name="description[]"></td>
                        <td><input type="number" step="0.01" name="unit_price[]" class="unit-price"></td>
                        <td><input type="number" name="quantity[]" class="qty"></td>
                        <td><input type="number" step="0.01" name="amount[]" class="row-amount" readonly></td>
                        <td><button type="button" class="btn btn-danger btn-sm remove-row">✕</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button type="button" class="btn btn-ghost btn-sm btn-add-row" id="add-row">+ Add Row</button>
        <div class="form-grid g-4 mt-1">
            <div class="form-group"><label>Total Amount</label><input type="number" step="0.01" name="total_amount" id="total_amount" readonly></div>
            <div class="form-group g-span-2"><label>Total Amount (in words)</label><input type="text" name="amount_words"></div>
        </div>
    </div>

    <div class="form-card">
        <div class="form-section-title">Approval Pipeline</div>
        <div class="pipeline-preview">
            <div class="pipeline-step"><i class="ti ti-send"></i><span>You submit</span></div>
            <i class="ti ti-chevron-right pipeline-arrow"></i>
            <div class="pipeline-step"><i class="ti ti-user-check"></i><span>Checker Approval</span></div>
            <i class="ti ti-chevron-right pipeline-arrow"></i>
            <div class="pipeline-step"><i class="ti ti-building-bank"></i><span>Review Approval</span></div>
            <i class="ti ti-chevron-right pipeline-arrow"></i>
            <div class="pipeline-step"><i class="ti ti-circle-check"></i><span>Grant Approval</span></div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
    <button type="draft" class="btn btn-light">Save as Draft</button>
</form>
